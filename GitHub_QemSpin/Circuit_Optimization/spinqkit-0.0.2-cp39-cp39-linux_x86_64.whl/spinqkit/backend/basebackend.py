
class BaseBackend:
    def __init__(self, *args, **kwargs):
        pass

    def set_config(self, *args, **kwargs):
        raise NotImplementedError

    def execute(self, *args, **kwargs):
        raise NotImplementedError

    def expval(self, *args, **kwargs):
        raise NotImplementedError

    def grads(self, *args, **kwargs):
        raise NotImplementedError

    def update_param(self, *args, **kwargs):
        raise NotImplementedError
