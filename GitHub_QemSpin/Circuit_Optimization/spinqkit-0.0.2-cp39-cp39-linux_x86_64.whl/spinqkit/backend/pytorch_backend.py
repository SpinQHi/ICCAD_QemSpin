from typing import List, Iterable

import numpy as np
import torch

from spinqkit.backend.basebackend import BaseBackend

dtype = torch.complex64

_X = torch.tensor([[0, 1],
                   [1, 0]]).to(dtype)

_Y = torch.tensor([[0, -1j],
                   [1j, 0]]).to(dtype)

_Z = torch.tensor([[1, 0],
                   [0, -1]]).to(dtype)

_I = torch.eye(2, dtype=dtype)

_H = 1 / torch.sqrt(torch.tensor(2)) * torch.tensor([[1, 1],
                                                     [1, -1]]).to(dtype)


def _P(x):
    return torch.tensor([[1, 0], [0, torch.exp(1j * x)]]).to(dtype)


_T = torch.tensor([[1, 0],
                   [0, (1 + 1j) / torch.sqrt(torch.tensor(2))]]).to(dtype)

_Td = torch.tensor([[1, 0],
                    [0, (1 - 1j) / torch.sqrt(torch.tensor(2))]]).to(dtype)

_S = torch.tensor([[1, 0],
                   [0, 1j]]).to(dtype)

_Sd = torch.tensor([[1, 0],
                    [0, -1j]]).to(dtype)

_CX = torch.tensor([
    [1, 0, 0, 0],
    [0, 1, 0, 0],
    [0, 0, 0, 1],
    [0, 0, 1, 0],
]).to(dtype)

_CZ = torch.tensor(
    [[1, 0, 0, 0],
     [0, 1, 0, 0],
     [0, 0, 1, 0],
     [0, 0, 0, -1]]
).to(dtype)

_CY = torch.tensor(
    [[1, 0, 0, 0],
     [0, 1, 0, 0],
     [0, 0, 0, -1j],
     [0, 0, 1j, 0]]
).to(dtype)


def _Rx(x):
    return (torch.cos(x / 2) * _I - 1j * torch.sin(x / 2) * _X).to(dtype)


def _Ry(x):
    return (torch.cos(x / 2) * _I - 1j * torch.sin(x / 2) * _Y).to(dtype)


def _Rz(x):
    return (torch.cos(x / 2) * _I - 1j * torch.sin(x / 2) * _Z).to(dtype)


gate_map = {'x': _X,
            'y': _Y,
            'z': _Z,
            'h': _H,
            'rx': _Rx,
            'ry': _Ry,
            'rz': _Rz,
            'cx': _CX,
            'cz': _CZ,
            'cy': _CY,
            'p': _P,
            't': _T,
            'tdg': _Td,
            's': _S,
            'sdg': _Sd}


class TorchSimulatorConfig:
    def __init__(self):
        pass


class TorchResult:
    def __init__(self):
        self.states = None


class TorchSimulator:
    """
    Using pytorch to simulate the quantum circuit
    """

    def __init__(self):
        pass

    def __call__(self, exe, params) -> torch.Tensor:
        """

        Args:
            exe (IntermediateRepresentation): calculate graph for quantum circuit.
            params (torch.Tensor):
        Return:
            final_state:torch.Tensor

        """
        qubits_num = exe.qnum
        state = torch.tensor([1.0] + [0.0] * (2 ** qubits_num - 1)).to(dtype)

        final_state = self._get_final_state(exe, state, params, qubits_num)
        return final_state

    def _get_final_state(self, ir, state, params, qubits_num):
        for v in ir.dag.vs:
            if v['type'] == 0:
                label = v['name'].lower()
                if not v['params']:
                    gate = gate_map[label]
                else:
                    _p = v['params']
                    if 'trainable' in v.attributes() and v['trainable']:
                        func = v['trainable']
                        gate = gate_map[label](func(params))
                    else:
                        if not isinstance(_p, torch.Tensor):
                            _p = torch.tensor(_p)
                        gate = gate_map[label](_p)
                state = self._apply_gate(state, gate, v['qubits'], qubits_num)
        return state

    def _apply_gate(self, state: torch.Tensor, gate: torch.Tensor,
                    qubit_idx: List[int], num_qubits: int) -> torch.Tensor:
        higher_dims = list(state.shape[:-1])
        num_higher_dims = len(higher_dims)

        if not isinstance(qubit_idx, Iterable):
            qubit_idx = [qubit_idx]

        num_acted_qubits = len(qubit_idx)
        origin_seq = list(range(num_qubits))
        seq_for_acted = qubit_idx + [x for x in origin_seq if x not in qubit_idx]
        swapped = [False] * num_qubits
        swap_ops = []
        for idx in range(num_qubits):
            if not swapped[idx]:
                next_idx = idx
                swapped[next_idx] = True
                while not swapped[seq_for_acted[next_idx]]:
                    swapped[seq_for_acted[next_idx]] = True
                    if next_idx < seq_for_acted[next_idx]:
                        swap_ops.append((next_idx, seq_for_acted[next_idx]))
                    else:
                        swap_ops.append((seq_for_acted[next_idx], next_idx))
                    next_idx = seq_for_acted[next_idx]
        perm = list(range(num_higher_dims)) + [item + num_higher_dims for item in [0, 3, 2, 1, 4]]
        state = self._helper(state, swap_ops, higher_dims, num_qubits, perm)
        state = torch.reshape(state,
                              higher_dims.copy() + [2 ** num_acted_qubits, 2 ** (num_qubits - num_acted_qubits)])
        state = torch.matmul(gate, state)
        swap_ops.reverse()
        state = self._helper(state, swap_ops, higher_dims, num_qubits, perm)
        state = torch.reshape(state, higher_dims.copy() + [2 ** num_qubits])
        return state

    @staticmethod
    def _helper(state, swap_ops, higher_dims, num_qubits, perm):
        for swap_op in swap_ops:
            shape = higher_dims.copy()
            last_idx = -1
            for idx in swap_op:
                shape.append(2 ** (idx - last_idx - 1))
                shape.append(2)
                last_idx = idx
            shape.append(2 ** (num_qubits - last_idx - 1))
            state = state.reshape(shape).permute(perm)
        return state


class TorchSimulatorBackend(BaseBackend):
    def __init__(self, shots=1024, params=None, ):
        super().__init__()
        if not isinstance(params, torch.Tensor):
            if isinstance(params, np.ndarray):
                params = torch.from_numpy(params)
                params.requires_grad_()
            else:
                params = torch.tensor(params, requires_grad=True)

        self.params = params
        self.simulator = TorchSimulator()
        self.val = None

        # TODO maybe add to configure at torch backend
        self.shots = shots

    def execute(self, ir):
        state = self.simulator(ir, self.params)
        return state

    def expval(self, ir, hamiltonian):
        state = self.execute(ir)
        b = state.conj()
        k = hamiltonian @ state
        value = torch.real(b @ k)
        self.val = value
        return value

    def grads(self, method):
        if method != 'backprop':
            raise NotImplementedError('The torch backend only supported `backprop` grad_method')
        self.val.backward()
        return self.params.grad.detach().numpy()

    def update_param(self, ir, new_params):
        """
        Set the new_params to the backend and Update the trainable params
        For torch backend It is not necessary
        """
        if not isinstance(new_params, torch.Tensor):
            if isinstance(new_params, np.ndarray):
                new_params = torch.from_numpy(new_params)
            else:
                new_params = torch.tensor(new_params)
            new_params.requires_grad_()
        self.params = new_params

    def set_config(self, shots=None, qubits=None):
        raise NotImplementedError


if __name__ == '__main__':
    pass
