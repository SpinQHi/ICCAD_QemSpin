# Copyright 2021 SpinQ Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from typing import List
from typing import Optional

import numpy as np
from numpy.random import default_rng

from spinqkit import GateBuilder, CZ, Rz, Ry
from spinqkit.compiler.decomposer import build_gate_for_isometry
from spinqkit.compiler.decomposer import decompose_zyz
from spinqkit.model import Instruction
from spinqkit.model.gates import Ph

_EPS = 1e-10
DEFAULT_RNG = default_rng()


def random_unitary(dims, seed=None):
    """Return a random unitary matrix.

    The operator is sampled from the unitary Haar measure.

    Args:
        dims (int or tuple): the input dimensions of the Operator.
        seed (int or np.random.Generator): Optional. Set a fixed seed or
                                           generator for RNG.

    Returns:
        np.ndarray: Matrix
    """
    if seed is None:
        random_state = DEFAULT_RNG
    elif isinstance(seed, np.random.Generator):
        random_state = seed
    else:
        random_state = default_rng(seed)

    dim = np.product(dims)
    from scipy import stats

    mat = stats.unitary_group.rvs(dim, random_state=random_state)
    return mat


def haar_density_operator(num_qubits: int, rank: Optional[int] = None,
                          is_real: Optional[bool] = False):
    r""" randomly generate a density matrix following Haar random
        Args:
            num_qubits: number of qubits
            rank: rank of density matrix, default to be False refering to full ranks
            is_real: whether the density matrix is real, default to be False
        Returns:
            a :math:`2^n \times 2^n` density matrix
    """
    dim = 2 ** num_qubits
    rank = rank if rank is not None else dim
    assert 0 < rank <= dim, 'rank is an invalid number'
    if is_real:
        ginibre_matrix = np.random.randn(dim, rank)
        rho = ginibre_matrix @ ginibre_matrix.T
    else:
        ginibre_matrix = np.random.randn(dim, rank) + 1j * np.random.randn(dim, rank)
        rho = ginibre_matrix @ ginibre_matrix.conj().T
    rho = rho / np.trace(rho)
    return rho / np.trace(rho)


def generate_vector_encoding(vector: np.ndarray, qubits: List) -> List[Instruction]:
    if len(vector.shape) == 1:
        vector = vector.reshape(vector.shape[0], 1)

    nb = int(np.log2(len(vector)))
    if nb != len(qubits):
        raise ValueError
    vector = vector / np.linalg.norm(vector)

    inst_list = []
    if len(qubits) == 1:
        # Construct a normalized unitary matrix
        mat = 1 / np.linalg.norm(vector) * np.array(
            [[vector[0, 0], -vector[1, 0].conjugate()], [vector[1, 0], vector[0, 0].conjugate()]])
        alpha, beta, gamma, phase = decompose_zyz(mat)
        _EPS = 1e-10
        if abs(alpha - 0.0) > _EPS:
            inst_list.append(Instruction(Rz, qubits, [], alpha))
        if abs(beta - 0.0) > _EPS:
            inst_list.append(Instruction(Ry, qubits, [], beta))
        if abs(gamma - 0.0) > _EPS:
            inst_list.append(Instruction(Rz, qubits, [], gamma))
        if abs(phase - 0.0) >= _EPS:
            inst_list.append(Instruction(Ph, qubits, [], phase))
    else:
        gate = build_gate_for_isometry(vector)
        inst_list.append(Instruction(gate, qubits[::-1], ))

    return inst_list


def _unitary_matrix(x, y):
    coeff = 1 / np.linalg.norm([x, y], 2)
    mat = np.array([[x, y], [-y.conjugate(), x.conjugate()]], dtype=complex)
    return coeff * mat


class StatePreparationGateBuilder(GateBuilder):
    """
    Arbitrary 2-qubit state preparation
    This class supported both density matrix and state vector

    For more details, see the article:
        1. scar Perdomo, Nelson Castaneda, and Roger Vogeler.
           Preparation of 3-qubit states. arXiv preprint arXiv:2201.03724, 2022.

    Examples:
        from spinqkit.primitive.vector_encoding import StatePreparationGateBuilder

        state_preparation = StatePreparationGateBuilder(2)
        gate = state_preparation.to_gate()
    """

    def __init__(self, state: np.ndarray):
        if len(state.shape) == 1:
            state = np.kron(state.reshape(-1, 1), state.conjugate())
        qubit_num = int(np.log2(state.shape[0]))
        if qubit_num != 2:
            raise ValueError('Only Supported 2-qubit state')
        purity = np.trace(state @ state)
        if abs(abs(purity) - 1) > 1e-6:
            raise ValueError('The state should be pure state.')
        super().__init__(qubit_num)

        # Get the w1 matrix
        eigval, eigvec = np.linalg.eig(state)
        s = (abs(eigval) - 0.0) > _EPS
        u = eigvec.T
        state = np.select(s, u)
        a0, a1, a2, a3 = state
        A1 = np.array([a0, a1])
        A2 = np.array([a2, a3])
        A1_norm = np.linalg.norm(A1)
        A2_norm = np.linalg.norm(A2)
        inner_product = (A2 @ A1.reshape(-1, 1).conjugate())[0]
        if abs(inner_product - 0.0) < _EPS:
            k = (A2_norm / A1_norm)
        else:
            k = -(A2_norm / A1_norm) * (
                    inner_product / abs(inner_product))
        w1 = _unitary_matrix(a3 - k * a1, a2.conjugate() - k.conjugate() * a0.conjugate()).T

        # Get the w2 matrix
        czmat = CZ.get_matrix()
        i_w1 = np.kron(np.identity(2), w1)
        state = czmat @ i_w1 @ state
        b0, b1, b2, b3 = state
        w2 = _unitary_matrix(b1.conjugate(), b3.conjugate())

        # Get the w3 matrix
        w2_i = np.kron(w2, np.identity(2))
        state = w2_i @ state
        g0, g1, g2, g3 = state
        w3 = _unitary_matrix(g0.conjugate(), -g1.conjugate()).T

        # Construct the gatebuilder
        def add_arbitrary_single_qubit_gate(mat, target):
            alpha, beta, gamma, phase = decompose_zyz(mat)
            if abs(alpha - 0.0) > _EPS:
                self.append(Rz, [target], alpha)
            if abs(beta - 0.0) > _EPS:
                self.append(Ry, [target], beta)
            if abs(gamma - 0.0) > _EPS:
                self.append(Rz, [target], gamma)

            # if abs(phase - 0.0) > _EPS:
            #     self.append(X, [target])
            #     self.append(P, [target], phase)
            #     self.append(X, [target])
            #     self.append(P, [target], phase)

        add_arbitrary_single_qubit_gate(w2.conjugate().T, 0)
        add_arbitrary_single_qubit_gate(w3.conjugate().T, 1)
        self.append(CZ, [0, 1])
        add_arbitrary_single_qubit_gate(w1.conjugate().T, 1)
