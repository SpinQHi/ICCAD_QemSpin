# Copyright 2021 SpinQ Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import List
from spinqkit.model import *
from ..decomposer.ZYZdecomposer import decompose_zyz
from ..ir import IntermediateRepresentation as IR
import numpy as np

from ...model.parameter import Parameter


def _sub_param_fn(plambda, params):
    """
    For processing the params, check the index of params
    """
    if plambda is not None:
        sub_params = plambda(params)

        # For the parameterized circuit, we use class Parameter
        # The function should be recorded into sub_params for the gradient calculation
        if isinstance(sub_params, Parameter):
            sub_params.func = plambda
        if not isinstance(sub_params, np.ndarray):
            sub_params = [sub_params]
    else:
        sub_params = []
    return sub_params


def _helper_basis(decomposition, gate, qubits, sub_params):
    """
    It is mostly for the Parameterized Quantum Circuit,
    The params should be decomposed one to one for quantum gates
    """
    if gate.label == U.label:

        # For U3 gate, if using Parameter, record the func
        rz_fn = lambda x: x[[2]]
        ry_fn = lambda x: x[[0]]
        rz2_fn = lambda x: x[[1]]
        rz_param = rz_fn(sub_params)
        ry_param = ry_fn(sub_params)
        rz2_param = rz2_fn(sub_params)
        if isinstance(sub_params, Parameter):
            rz_param.func = rz_fn
            ry_param.func = ry_fn
            rz2_param.func = rz2_fn

        decomposition.append(Instruction(Rz, qubits, [], rz_param))
        decomposition.append(Instruction(Ry, qubits, [], ry_param))
        decomposition.append(Instruction(Rz, qubits, [], rz2_param))
    else:
        decomposition.append(Instruction(gate, qubits, [], sub_params))


def is_primary_gate(gate: Gate):
    if gate in IR.basis_set:
        return True
    elif isinstance(gate, MatrixGate):
        return True
    elif isinstance(gate, ControlledGate) and (isinstance(gate.base_gate, MatrixGate) or
                                               gate.base_gate in IR.basis_set):
        return True
    elif isinstance(gate, InverseGate) and (isinstance(gate.base_gate, MatrixGate) or
                                            gate.base_gate in IR.basis_set):
        return True
    return False


def decompose_single_qubit_gate(gate: Gate, qubits: List, params=None, basis=False) -> List:
    """
    Args:
        gate: class `Gate`
        qubits: List, The qubit list which contains qubits that gate applied on
        params: Optional[float,callable], default to None, params are only callable function or (int, float, numpy dtype)
        basis: bool, default to False, When basis is True The gate will be decomposed into the basis gate,
            see `basis_gate` in `spinqkit.mode.gates.basis_set` for more information.

    Return:
        List of Instruction
    """
    if params is None:
        params = []
    decomposition = []

    if len(gate.factors) > 0:
        for f in gate.factors:
            plambda = f[2] if len(f) > 2 else None
            sub_params = _sub_param_fn(plambda, params)
            if basis:
                if f[0] in IR.basis_set:
                    _helper_basis(decomposition, f[0], qubits, sub_params)
                else:
                    decomposition.extend(decompose_single_qubit_gate(f[0], qubits, sub_params, basis))
            else:
                if is_primary_gate(f[0]):
                    decomposition.append(Instruction(f[0], qubits, [], *sub_params))
                else:
                    decomposition.extend(decompose_single_qubit_gate(f[0], qubits, sub_params, basis))
    else:
        if basis and gate in IR.basis_set:
            _helper_basis(decomposition, gate, qubits, params)
        else:
            mat = gate.get_matrix(*params)
            if mat is None:
                raise UnsupportedGateError(gate.label + ' is not supported. Its matrix representation is None.')
            alpha, beta, gamma, phase = decompose_zyz(mat)
            decomposition.append(Instruction(Rz, qubits, [], alpha))
            decomposition.append(Instruction(Ry, qubits, [], beta))
            decomposition.append(Instruction(Rz, qubits, [], gamma))

    return decomposition


def decompose_multi_qubit_gate(gate: Gate, qubits: List, params=None, basis=False) -> List:
    if params is None:
        params = []
    if len(gate.factors) > 0:
        decomposition = []
        for f in gate.factors:
            sub_qubits = [qubits[i] for i in f[1]]
            plambda = f[2] if len(f) > 2 else None
            sub_params = _sub_param_fn(plambda, params)
            if basis:
                if f[0] in IR.basis_set:
                    _helper_basis(decomposition, f[0], sub_qubits, sub_params)
                else:
                    if f[0].qubit_num == 1:
                        decomposition.extend(decompose_single_qubit_gate(f[0], sub_qubits, sub_params, basis))
                    else:
                        decomposition.extend(decompose_multi_qubit_gate(f[0], sub_qubits, sub_params, basis))
            else:
                if is_primary_gate(f[0]):
                    decomposition.append(Instruction(f[0], sub_qubits, [], *sub_params))
                elif f[0].qubit_num == 1:
                    decomposition.extend(decompose_single_qubit_gate(f[0], sub_qubits, sub_params, basis))
                else:
                    decomposition.extend(decompose_multi_qubit_gate(f[0], sub_qubits, sub_params, basis))
        return decomposition

    raise UnsupportedGateError(gate.label + ' is not supported.')
