# Copyright 2021 SpinQ Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from typing import Union

import numpy as np

from spinqkit import CNOT, CCX, P, X, Rz, Ry, H, Z
from spinqkit.compiler.decomposer import decompose_zyz
from spinqkit.model import Gate, GateBuilder


class MultiControlledGateBuilder(GateBuilder):
    """
    Construct Multi Controlled Gate (MCG) using quantum multiplexor method.

    For more details, see article:
        1. Barenco, Bennett et al. Elementary gates for quantum computation. 1995. https://arxiv.org/pdf/quant-ph/9503016.pdf
    """

    def __init__(self, ctrl_num: int, gate: Union[Gate, np.ndarray, list], params=None):
        super().__init__(ctrl_num + 1)
        if gate.qubit_num > 1:
            raise ValueError('The MCG only support single qubit gate')
        if isinstance(gate, Gate):
            if params is not None:
                mat = gate.get_matrix(params)
            else:
                mat = gate.get_matrix()
        elif isinstance(gate, list):
            mat = np.array(gate)
        else:
            mat = gate

        self.gate_mat = mat
        self.decompose(self.gate_mat, controls=list(range(ctrl_num)), target=ctrl_num)

    def _ccnot_congruent(self, c0, c1, target):
        self.append(Ry, target, -np.pi / 4)
        self.append(CNOT, [c1, target])
        self.append(Ry, target, -np.pi / 4)
        self.append(CNOT, [c0, target])
        self.append(Ry, target, np.pi / 4)
        self.append(CNOT, [c1, target])
        self.append(Ry, target, np.pi / 4)

    def _ccnot(self, c0, c1, target, congruent=False):

        if congruent:
            self._ccnot_congruent(c0, c1, target)
        else:
            self.append(CCX, [c0, c1, target])

    def _multi_ctrl_x(self, controls, target, free_qubits=None):
        # control num
        if free_qubits is None:
            free_qubits = []
        m = len(controls)

        if m == 0:
            self.append(X, target)
            return
        elif m == 1:
            self.append(CNOT, controls + [target])
        elif m == 2:
            self.append(CCX, controls + [target])

        else:
            # qubit_num
            n = m + 1 + len(free_qubits)

            if (n >= 2 * m - 1) and (m >= 3):
                def helper():
                    self._ccnot(controls[m - 1],
                                free_qubits[m - 3],
                                target)

                    # See [1], Lemma 7.2.
                    for i in range(m - 3):
                        self._ccnot(controls[m - 2 - i],
                                    free_qubits[m - 4 - i],
                                    free_qubits[m - 3 - i],
                                    congruent=True)
                    self._ccnot(controls[0],
                                controls[1],
                                free_qubits[0],
                                congruent=True)
                    for i in range(m - 2, -1, -1):
                        self._ccnot(controls[m - 2 - i],
                                    free_qubits[m - 4 - i],
                                    free_qubits[m - 3 - i],
                                    congruent=True)

                for _ in range(2):
                    helper()
            elif len(free_qubits) >= 1:
                # See [1], Lemma 7.3.
                m1 = n // 2
                free1 = controls[m1:] + [target] + free_qubits[1:]
                ctrl1 = controls[:m1]
                free2 = controls[:m1] + free_qubits[1:]
                ctrl2 = controls[m1:] + [free_qubits[0]]
                for _ in range(2):
                    self._multi_ctrl_x(ctrl1, free_qubits[0], free_qubits=free1)
                    self._multi_ctrl_x(ctrl2, target, free_qubits=free2)
            else:
                # No free qubit - must use main algorithm.
                # This will never happen if called from main algorithm and is added
                # only for completeness.
                self.decompose(X.get_matrix(), controls, target)

    def decompose(self, matrix, controls, target, free_qubits=None, power=1.0, ):
        if free_qubits is None:
            free_qubits = []
        u = self._unitary_power(matrix, power)

        # Matrix parameters, see definitions in [1], chapter 4.
        beta, theta, alpha, delta = decompose_zyz(u)

        A = Rz.get_matrix(alpha) @ Ry.get_matrix(theta / 2)
        B = Ry.get_matrix(-theta / 2) @ Rz.get_matrix(-(alpha + beta) / 2)
        C = Rz.get_matrix((beta - alpha) / 2)
        if not np.allclose(A @ B @ C, np.eye(2), atol=1e-4):
            print('alpha', alpha)
            print('beta', beta)
            print('theta', theta)
            print('delta', delta)
            print('A', A)
            print('B', B)
            print('C', C)
            print(np.abs(A @ B @ C))
        assert np.allclose(A @ B @ C, np.eye(2), atol=1e-2)
        assert np.allclose(
            A @ X.get_matrix() @ B @ X.get_matrix() @ C,
            u /
            np.exp(
                1j *
                delta),
            atol=1e-2)

        ctrl_num = len(controls)
        ctrl = controls
        assert ctrl_num > 0, "No control qubits."
        if ctrl_num == 1:
            # See [1], chapter 5.1.
            self.append(Rz, target, 0.5 * (beta - alpha))
            self.append(CNOT, [ctrl[0], target])
            self.append(Rz, [target], -0.5 * (beta + alpha))
            self.append(Ry, [target], -0.5 * theta)
            self.append(CNOT, [ctrl[0], target])
            self.append(P, [ctrl[0]], delta)
            self.append(Ry, [target], 0.5 * theta)
            self.append(Rz, [target], alpha)
        else:
            gate_is_special_unitary = np.allclose(delta, 0)

            if gate_is_special_unitary:
                self.decompose(C, [ctrl[-1]], target)
                self._multi_ctrl_x(ctrl[:-1], target, free_qubits=[ctrl[-1]])
                self.decompose(B, [ctrl[-1]], target)
                self._multi_ctrl_x(ctrl[:-1], target, free_qubits=[ctrl[-1]])
                self.decompose(A, [ctrl[-1]], target)
            else:
                self.decompose(matrix, [ctrl[-1]], target, power=0.5 * power)
                self._multi_ctrl_x(ctrl[:-1], ctrl[-1], free_qubits=free_qubits + [target])
                self.decompose(matrix, [ctrl[-1]], target, power=-0.5 * power)
                self._multi_ctrl_x(ctrl[:-1], ctrl[-1], free_qubits=free_qubits + [target])
                self.decompose(matrix, ctrl[:-1], target, power=0.5 * power,
                               free_qubits=free_qubits + [ctrl[-1]])

    @staticmethod
    def _unitary_power(U, p):
        """Raises unitary matrix U to power p."""
        eig_vals, Q = np.linalg.eig(U)
        return Q @ np.diag(np.exp(p * 1j * np.angle(eig_vals))) @ Q.conj().T
