# Copyright 2021 SpinQ Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from functools import reduce
from typing import List

import numpy as np

from spinqkit import Instruction, X
from spinqkit.model import Gate
from spinqkit.model.gates import basis_set


def print_gate_factors(gate: Gate, qubit: list, params=None) -> List:
    r"""
    The gate constructed by other basis gate which is included in the gate factors.
    Decompose the gate into basis gate

    Args:
        gate: class `Gate`
        qubit: List, The qubit list which contains qubits that gate applied on
        params: Optional[float,callable], default to None, params are only callable function or (int, float, numpy dtype)

    Return:
        List of Instruction
    """
    from spinqkit.compiler.translator.gate_converter import decompose_multi_qubit_gate, decompose_single_qubit_gate
    if gate in basis_set:
        res = [Instruction(gate, qubit, [], params)]
    else:
        if gate.qubit_num == 1:
            res = decompose_single_qubit_gate(gate,
                                              qubit,
                                              None if not params else params,
                                              basis=True)
        else:
            res = decompose_multi_qubit_gate(gate,
                                             qubit,
                                             None if not params else params,
                                             basis=True)
    return res


def gate_matrix(gate_list: List[Instruction], qubit_num: int) -> np.ndarray:
    r"""
    Calculate the gate matrix, while gate_list can be obtained by func `print_gate_factors`,
    which decompose the gate and return the gate_list (Instruction list)

    """
    matrix = np.identity(2 ** qubit_num)
    for inst in gate_list:
        gate, qubit, param = inst.gate, inst.qubits, inst.params
        mat = _get_matrix(gate, qubit, qubit_num, param)
        matrix = mat @ matrix
    return matrix


def _get_matrix(gate, gate_qubit, qubit_num, param=None):
    """
    Convert every single gate to matrix, which shape is `[2**qubit_num, 2**qubit_num]`
    """
    if gate.label == 'CX':
        gate_list_0, gate_list_1 = _construct_cnot_gate_list(qubit_num, gate_qubit)
        return nkron(gate_list_0) + nkron(gate_list_1)
    else:
        gate_list = _construct_normal_gate_list(gate, gate_qubit, qubit_num, param=param)
        return nkron(gate_list)


def _construct_cnot_gate_list(qubit_num, qubit):
    """
    Obtain the gate list to construct the `CX` gate matrix,
    especially the control and target qubits are not neighbor `CX` gate
    """
    control, target = qubit[0], qubit[1]
    gate_list_0 = [np.identity(2) for _ in range(qubit_num)]
    gate_list_0[control] = np.array([[1, 0],
                                     [0, 0]])
    gate_list_1 = [np.identity(2) for _ in range(qubit_num)]
    gate_list_1[control] = np.array([[0, 0],
                                     [0, 1]])
    gate_list_1[target] = X.get_matrix()
    return gate_list_0, gate_list_1


def _construct_normal_gate_list(gate, gate_qubit, qubit_num, param=None):
    if param is not None and len(param) > 0:
        gate = gate.get_matrix(param)
    else:
        gate = gate.get_matrix()
    gate_list = [np.identity(2) for _ in range(qubit_num)]
    gate_list[gate_qubit[0]] = gate
    filter_list = [True] * qubit_num
    for i in gate_qubit[1:]:
        filter_list[i] = False
    func = lambda x: filter_list[x]
    gate_list = [gate_list[i] for i in filter(func, list(range(qubit_num)))]
    return gate_list


def nkron(gate_list):
    return reduce(np.kron, gate_list)


if __name__ == '__main__':
    pass
