# Copyright 2021 SpinQ Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from typing import List, Tuple, Union
from collections import defaultdict

import numpy as np
from autograd import grad, jacobian, elementwise_grad

from spinqkit.model.gates import MEASURE, Rz, Ry, basis_set
from .basic_gate import Gate
from .instruction import Instruction
from .parameter import Parameter
from .register import QuantumRegister, ClassicalRegister
from spinqkit.utils.function import _flatten


def _expand_parameter_gate(gate, qubits, params):
    from spinqkit.compiler.translator.gate_converter import decompose_multi_qubit_gate, \
        decompose_single_qubit_gate

    if gate.qubit_num == 1:
        ilist = decompose_single_qubit_gate(gate, qubits, params, basis=True)
    else:
        ilist = decompose_multi_qubit_gate(gate, qubits, params, basis=True)
    return ilist


class Circuit(object):
    def __init__(self, params=None):
        if params is not None:
            if not isinstance(params, np.ndarray):
                raise ValueError('The type of parameter should be np.ndarray')
            if len(params.shape) > 1:
                raise ValueError('The parameter should be 1-dimensions')
            self.__params = params.reshape(-1)
        else:
            self.__params = None

        self.__qubits_num = 0
        self.__clbits_num = 0
        self.__qureg_list = []
        self.__clreg_list = []
        self.__instructions = []

        self.inst_param_map = {}
        self.param_inst_map = defaultdict(list)

    @property
    def qubits(self):
        return [i for i in range(self.__qubits_num)]

    @property
    def qubits_num(self):
        return self.__qubits_num

    @property
    def clbits_num(self):
        return self.__clbits_num

    @property
    def qureg_list(self):
        return self.__qureg_list

    @property
    def clreg_list(self):
        return self.__clreg_list

    @property
    def instructions(self) -> List[Instruction]:
        return self.__instructions

    @property
    def params(self) -> np.ndarray:
        return self.__params

    def allocateQubits(self, num: int):
        reg = QuantumRegister(num, self.__qubits_num)
        self.__qureg_list.append(num)
        self.__qubits_num += num
        return reg

    def allocateClbits(self, num: int):
        reg = ClassicalRegister(num, self.__clbits_num)
        self.__clreg_list.append(num)
        self.__clbits_num += num
        return reg

    def __lshift__(self, other: Tuple):
        gate = other[0]
        qubits = list(_flatten((other[1],)))
        p = other[2:]
        if not any(callable(x) for x in p):
            self.append(gate, qubits, [], *p)
        else:
            params = self.__params
            if params is None:
                raise ValueError('The parameter of the circuit should be setting first')
            plambda = p[0]
            qubits = list(_flatten((qubits,)))
            sub_params = plambda(params)
            if isinstance(sub_params, Parameter):
                sub_params.func = plambda

            gate_list = _expand_parameter_gate(gate, qubits, sub_params)
            for ins in gate_list:
                if getattr(ins.params, 'trainable', None):
                    self.inst_param_map[len(self.instructions)] = (grad(ins.params.func)(params)[ins.params.index],
                                                                   ins.params.index)
                    self.param_inst_map[tuple(_flatten(ins.params.index))].append(len(self.instructions))
                self.append_instruction(ins)
        return self

    def __or__(self, other: Tuple):
        self.__instructions[-1].set_condition(other[0], other[1], other[2])

    def measure(self, qubits: Union[int, List[int]], clbits: Union[int, List[int]]):
        if isinstance(qubits, int):
            qubits = [qubits]
        if isinstance(clbits, int):
            clbits = [clbits]
        if len(qubits) != len(clbits):
            raise Exception('The number of qubits does not match the number of classical bits.')
        self.__instructions.append(Instruction(MEASURE, qubits, clbits))

    def append(self, gate: Gate, qubits=None, clbits=None, *params: Tuple):
        if clbits is None:
            clbits = []
        if qubits is None:
            qubits = []
        self.__instructions.append(Instruction(gate, qubits, clbits, *params))

    def append_instruction(self, inst: Instruction):
        self.__instructions.append(inst)

    def extend(self, inst_list: List):
        for inst in inst_list:
            self.append_instruction(inst)
