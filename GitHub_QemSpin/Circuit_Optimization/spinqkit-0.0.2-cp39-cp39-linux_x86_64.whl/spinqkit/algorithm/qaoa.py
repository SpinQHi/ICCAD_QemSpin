# Copyright 2021 SpinQ Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from typing import List

import numpy as np

from spinqkit.algorithm.Expval import ExpvalCost
from spinqkit.model import Circuit, H, Rx
from spinqkit.model.Ising_gate import Z_IsingGateBuilder
from spinqkit.model.parameter import Parameter


class QAOA(object):
    def __init__(
            self,
            qubit_num: int,
            depth: int,
            hamiltonian: List,
            circuit=None,
            circuit_params: np.ndarray = None,
            problem_param_num=1,
            mixer_param_num=1,
            optimizer=None
    ):

        if circuit_params is not None:
            if not isinstance(circuit_params, Parameter):
                self.params = Parameter(circuit_params, trainable='True')
            else:
                self.params = circuit_params
        else:
            self.params = Parameter(np.random.uniform(low=0, high=2 * np.pi,
                                                      size=(mixer_param_num + problem_param_num) * depth),
                                    trainable='True')

        self.__qubit_num = qubit_num
        self.__mixer_param_num = mixer_param_num
        self.__problem_param_num = problem_param_num
        self.__depth = depth
        self.fn = None

        self.hamiltonian = hamiltonian
        self.optimizer = optimizer
        if circuit is not None:
            self.circuit = circuit
            self.params = circuit.params
        else:
            self.circuit = self._build()

    def _create_cost_circuit(self, circ, param_idx):
        ham = self.hamiltonian
        for i in range(len(ham)):
            if 'Z' in ham[i][0]:
                qubits = [idx for idx in range(len(ham[i][0])) if ham[i][0][idx] == 'Z']
                rzz = Z_IsingGateBuilder(len(qubits) - 1).to_gate()
                circ << (rzz, qubits, lambda x, coeff=ham[i][1], idx=param_idx: coeff * x[idx])

    def _generate_mixer(self, circ, param_idx):
        for i in range(self.__qubit_num):
            circ << (Rx, [i], lambda x, idx=param_idx[0]: x[idx],)

    def _build(self, ) -> Circuit:
        if len(self.params) != (self.__mixer_param_num + self.__problem_param_num) * self.__depth:
            raise ValueError('The number of parameters is not right')

        circ = Circuit(self.params)
        qubits = circ.allocateQubits(self.__qubit_num)

        for i in range(len(qubits)):
            circ << (H, qubits[i])

        for i in range(self.__depth):
            p_num = self.__problem_param_num + self.__mixer_param_num

            self._create_cost_circuit(circ, list(range(i * p_num, i * p_num + self.__problem_param_num)))
            self._generate_mixer(circ, list(range(i * p_num + self.__problem_param_num, (i + 1) * p_num)))
        return circ

    def run(self, mode, grad_method, hamiltonian=None):
        """
            Args:
               mode (str): The backend mode, only supported `spinq` or `torch`.
               grad_method (str):
                        For `spinq` backend, the grad_method have `param_shift` and `adjoint_differentiation`
                        For `torch` backend, the grad_method have `backprop`

            Return:
                The optimize step loss list.
        """
        if self.optimizer is None:
            raise ValueError(f'The optimizer should be given in {self.__class__.__name__}.__init__()')
        optimizer = self.optimizer

        if hamiltonian is not None:
            self.hamiltonian = hamiltonian

        expvalcost = ExpvalCost(self.circuit, self.params, self.hamiltonian, backend_mode=mode, grad_method=grad_method)
        loss_list = optimizer.optimize(expvalcost)
        return loss_list

    def get_optimize_result(self):
        if self.fn is None:
            raise ValueError(
                f'Use {self.__class__.__name__}.run() to optimize the parameterized quantum circuit first.')
        result = self.fn.run_ir(self.fn.exe)
        # todo different backend return different result
        return result
