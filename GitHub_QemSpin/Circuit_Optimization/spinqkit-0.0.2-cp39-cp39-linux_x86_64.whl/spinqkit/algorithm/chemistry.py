from typing import Tuple, List, Any
import os
import numpy as np
import pennylane as qml
from pennylane import qchem
from pennylane.operation import Observable, Tensor

from spinqkit import Circuit, CX, H, Ry, X

OBS_MAP = {"PauliX": "X", "PauliY": "Y", "PauliZ": "Z", "Hadamard": "H", "Identity": "I"}
bohr_angs = 0.529177210903


def convert_hamiltanion(ham, num_qubits) -> List[Tuple]:
    """
    Extract out the coefficients and pauli string of Pennylane class "Hamiltonian"
    """
    hamiltonian = []
    list_of_coeffs = ham.data  # list of scalar tensors
    paired_coeff_obs = list(zip(list_of_coeffs, ham.ops))
    paired_coeff_obs.sort(key=lambda pair: (len(pair[1].wires), pair[0]))

    def wires_print(ob: Observable):
        """Function that formats the wires."""
        return ",".join(map(str, ob.wires.tolist()))

    for coeff, obs in paired_coeff_obs:
        pauli_str = ['I'] * num_qubits
        if isinstance(obs, Tensor):
            ob = [(OBS_MAP.get(ob.name, ob.name), int(wires_print(ob))) for ob in obs.obs]
        elif isinstance(obs, Observable):
            ob = [(OBS_MAP.get(obs.name, obs.name), int(wires_print(obs)))]
        for p_str, site in ob:
            pauli_str[site] = p_str
        pauli_str = ''.join(pauli_str)
        hamiltonian.append((pauli_str, coeff.tolist()))
    return hamiltonian


def _basis_state(circ: Circuit, state):
    print(state)
    for idx, s in enumerate(state):
        if s == 1:
            circ << (X, [idx])


def _double_excitation(circ: Circuit, qubits):
    circ << (CX, [qubits[2], qubits[3]])
    circ << (CX, [qubits[0], qubits[2]])
    circ << (H, qubits[3])
    circ << (H, qubits[0])
    circ << (CX, [qubits[2], qubits[3]])
    circ << (CX, [qubits[0], qubits[1]])
    circ << (Ry, qubits[1], lambda x: x[0] / 8)
    circ << (Ry, qubits[0], lambda x: -x[0] / 8)
    circ << (CX, [qubits[0], qubits[3]])
    circ << (H, [qubits[3]])
    circ << (CX, [qubits[3], qubits[1]])
    circ << (Ry, qubits[1], lambda x: x[0] / 8)
    circ << (Ry, qubits[0], lambda x: -x[0] / 8)
    circ << (CX, [qubits[2], qubits[1]])
    circ << (CX, [qubits[2], qubits[0]])
    circ << (Ry, qubits[1], lambda x: -x[0] / 8)
    circ << (Ry, qubits[0], lambda x: x[0] / 8)
    circ << (CX, [qubits[3], qubits[1]])
    circ << (H, [qubits[3]])
    circ << (CX, [qubits[0], qubits[3]])
    circ << (Ry, qubits[1], lambda x: -x[0] / 8)
    circ << (Ry, qubits[0], lambda x: x[0] / 8)
    circ << (CX, [qubits[0], qubits[1]])
    circ << (CX, [qubits[2], qubits[0]])
    circ << (H, qubits[0])
    circ << (H, qubits[3])
    circ << (CX, [qubits[0], qubits[2]])
    circ << (CX, [qubits[2], qubits[3]])


def _excitations(electrons, orbitals, delta_sz=0):
    r"""Generate single and double excitations from a Hartree-Fock reference state.
    """

    if not electrons > 0:
        raise ValueError(
            f"The number of active electrons has to be greater than 0 \n"
            f"Got n_electrons = {electrons}"
        )

    if orbitals <= electrons:
        raise ValueError(
            f"The number of active spin-orbitals ({orbitals}) "
            f"has to be greater than the number of active electrons ({electrons})."
        )

    if delta_sz not in (0, 1, -1, 2, -2):
        raise ValueError(
            f"Expected values for 'delta_sz' are 0, +/- 1 and +/- 2 but got ({delta_sz})."
        )

    # define the spin projection 'sz' of the single-particle states
    sz = np.array([0.5 if (i % 2 == 0) else -0.5 for i in range(orbitals)])

    singles = [
        [r, p]
        for r in range(electrons)
        for p in range(electrons, orbitals)
        if sz[p] - sz[r] == delta_sz
    ]

    doubles = [
        [s, r, q, p]
        for s in range(electrons - 1)
        for r in range(s + 1, electrons)
        for q in range(electrons, orbitals - 1)
        for p in range(q + 1, orbitals)
        if (sz[p] + sz[q] - sz[r] - sz[s]) == delta_sz
    ]

    return singles, doubles


def _hf_state(electrons, orbitals):
    r"""Generate the occupation-number vector representing the Hartree-Fock state.
    """

    if electrons <= 0:
        raise ValueError(
            f"The number of active electrons has to be larger than zero; "
            f"got 'electrons' = {electrons}"
        )

    if electrons > orbitals:
        raise ValueError(
            f"The number of active orbitals cannot be smaller than the number of active electrons;"
            f" got 'orbitals'={orbitals} < 'electrons'={electrons}"
        )

    state = np.where(np.arange(orbitals) < electrons, 1, 0)

    return np.array(state)


def _ch4_setting(coordinates=np.array([2.7267, 2.9517, 2.3601,
                                       2.1090, 2.3339, 1.7423,
                                       3.3445, 2.3339, 2.9779,
                                       2.1090, 3.5694, 2.9779,
                                       3.3445, 3.5694, 1.7423]),
                 basis='mini'):
    symbols = ["C", "H", "H", "H", "H"]
    try:
        from openfermionpyscf import run_pyscf
        import openfermion
        from pennylane.qchem.convert import _openfermion_to_pennylane
        outpath = "."
        mult = 1
        charge = 0

        geometry = [
            [symbol, tuple(np.array(coordinates)[3 * i: 3 * i + 3] * bohr_angs)]
            for i, symbol in enumerate(symbols)
        ]

        symbol_str = "".join(symbols)
        filename = symbol_str + "_pyscf" + "_" + basis.strip()
        path_to_file = os.path.join(outpath.strip(), filename)

        molecule = openfermion.MolecularData(geometry, basis, mult, charge, filename=path_to_file)
        run_pyscf(molecule, run_scf=1, verbose=0)

        terms_molecular_hamiltonian = molecule.get_molecular_hamiltonian()

        fermionic_hamiltonian = openfermion.transforms.get_fermion_operator(terms_molecular_hamiltonian)
        ham = openfermion.transforms.jordan_wigner(fermionic_hamiltonian)

        qubits = molecule.n_qubits
        electrons = molecule.n_electrons
        ham = qml.Hamiltonian(*_openfermion_to_pennylane(ham, wires=list(range(qubits))))
        hamiltonian = convert_hamiltanion(ham, qubits)
        return electrons, hamiltonian, qubits
    except:

        H, qubits = qml.qchem.molecular_hamiltonian(symbols, coordinates)
        electrons = 10
        print("Number of qubits required to perform quantum simulations: {:}".format(qubits))
        ham = convert_hamiltanion(H, qubits)
        return electrons, ham, qubits


def _h2o_setting(coordinates=np.array([-0.0399, -0.0038, 0.0, 1.5780, 0.8540, 0.0, 2.7909, -0.5159, 0.0]),
                 basis="sto-3g"):

    symbols = ["H", "O", "H"]
    try:
        from openfermionpyscf import run_pyscf
        import openfermion
        from pennylane.qchem.convert import _openfermion_to_pennylane
        outpath = "."
        mult = 1
        charge = 0

        geometry = [
            [symbol, tuple(np.array(coordinates)[3 * i: 3 * i + 3] * bohr_angs)]
            for i, symbol in enumerate(symbols)
        ]
        symbol_str = "".join(symbols)

        filename = symbol_str + "_pyscf" + "_" + basis.strip()
        path_to_file = os.path.join(outpath.strip(), filename)

        molecule = openfermion.MolecularData(geometry, basis, mult, charge, filename=path_to_file)
        run_pyscf(molecule, run_scf=1, verbose=0)

        terms_molecular_hamiltonian = molecule.get_molecular_hamiltonian()

        fermionic_hamiltonian = openfermion.transforms.get_fermion_operator(terms_molecular_hamiltonian)
        ham = openfermion.transforms.jordan_wigner(fermionic_hamiltonian)

        qubits = molecule.n_qubits
        electrons = molecule.n_electrons
        ham = qml.Hamiltonian(*_openfermion_to_pennylane(ham, wires=list(range(qubits))))
        hamiltonian = convert_hamiltanion(ham, qubits)

        return electrons, hamiltonian, qubits
    except:
        electrons = 10
        H, qubits = qml.qchem.molecular_hamiltonian(symbols, coordinates)
        ham = convert_hamiltanion(H, qubits)
        return electrons, ham, qubits


def _h2_setting(coordinates=np.array([0.0, 0.0, -0.6614, 0.0, 0.0, 0.6614]),
                basis='sto-3g'):

    symbols = ["H", "H"]
    try:
        from openfermionpyscf import run_pyscf
        import openfermion
        from pennylane.qchem.convert import _openfermion_to_pennylane
        outpath = "."
        mult = 1
        charge = 0

        geometry = [
            [symbol, tuple(np.array(coordinates)[3 * i: 3 * i + 3] * bohr_angs)]
            for i, symbol in enumerate(symbols)
        ]
        symbol_str = "".join(symbols)

        filename = symbol_str + "_pyscf" + "_" + basis.strip()
        path_to_file = os.path.join(outpath.strip(), filename)
        # print(path_to_file)
        molecule = openfermion.MolecularData(geometry, basis, mult, charge, filename=path_to_file)
        run_pyscf(molecule, run_scf=1, verbose=0)
        # molecule = openfermion.MolecularData(filename=path_to_file)
        terms_molecular_hamiltonian = molecule.get_molecular_hamiltonian()
        # print(terms_molecular_hamiltonian)
        fermionic_hamiltonian = openfermion.transforms.get_fermion_operator(terms_molecular_hamiltonian)
        ham = openfermion.transforms.jordan_wigner(fermionic_hamiltonian)
        qubits = molecule.n_qubits
        electrons = molecule.n_electrons
        ham = qml.Hamiltonian(*_openfermion_to_pennylane(ham, wires=list(range(qubits))))
        hamiltonian = convert_hamiltanion(ham, qubits)
        return electrons, hamiltonian, qubits
    except:
        H, qubits = qml.qchem.molecular_hamiltonian(symbols, coordinates)
        electrons = 2
        ham = convert_hamiltanion(H, qubits)
        return electrons, ham, qubits


def construct_circuit(params, qubits, electrons, ):
    singles, doubles = _excitations(electrons, qubits)
    state = _hf_state(electrons, qubits)
    qubit_num = qubits
    circ = Circuit(params)
    circ.allocateQubits(qubit_num)
    _basis_state(circ, state)
    for d in doubles:
        _double_excitation(circ, d)
    return circ
