# Copyright 2021 SpinQ Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import List, Union

import numpy as np
import scipy.sparse

from spinqkit.model import Circuit, Rx, Rz, CX
from .Expval import ExpvalCost
from ..model.parameter import Parameter


class VQE(object):
    def __init__(self,
                 qubit_num: int,
                 depth: int,
                 hamiltonian: Union[np.ndarray, List, scipy.sparse.csr_matrix],
                 circuit: Circuit = None,
                 circuit_params: np.ndarray = None,
                 optimizer=None):
        """
        Hamiltonian is a matrix or a list of (pauli string, coeff).
        If it is a matrix, the expection value is calculated through matrix multiplication.
        If it is a list, the expection value is calculated through pauli measurements.
        """
        self.__qubit_num = qubit_num
        self.__depth = depth
        self.hamiltonian = hamiltonian
        self.optimizer = optimizer
        self.fn = None

        if circuit_params is not None:
            if not isinstance(circuit_params, Parameter):
                self.ansatz_params = Parameter(circuit_params, trainable=True)
            else:
                self.ansatz_params = circuit_params
        else:
            self.ansatz_params = Parameter(np.random.uniform(0, 2 * np.pi, 3 * self.__qubit_num * self.__depth),
                                           trainable=True)

        if circuit is not None:
            self.circuit = circuit
            self.ansatz_params = circuit.params
        else:
            self.circuit = self._build()

    def _build(self) -> Circuit:
        circ = Circuit(self.ansatz_params)
        circ.allocateQubits(self.__qubit_num)
        for d in range(self.__depth):
            for q in range(self.__qubit_num):
                circ << (Rx, [q], lambda x, idx=3 * self.__qubit_num * d + 3 * q: x[idx])
                circ << (Rz, [q], lambda x, idx=3 * self.__qubit_num * d + 3 * q + 1: x[idx])
                circ << (Rx, [q], lambda x, idx=3 * self.__qubit_num * d + 3 * q + 2: x[idx])
            if self.__qubit_num > 1:
                for q in range(self.__qubit_num - 1):
                    circ.append(CX, [q, q + 1])
                circ.append(CX, [self.__qubit_num - 1, 0])
        return circ

    def run(self, mode='spinq', grad_method='adjoint_differentiation'):
        """
            Args:
               mode (str): The backend mode, only supported `spinq` or `torch`.
               grad_method (str):
                        For `spinq` backend, the grad_method have `param_shift` and `adjoint_differentiation`
                        For `torch` backend, the grad_method have `backprop`

            Return:
                The optimize step loss list.
        """
        if self.optimizer is None:
            raise ValueError('The optimizer should be given in VQE.__init__()')
        optimizer = self.optimizer
        expvalcost = ExpvalCost(self.circuit, self.ansatz_params, self.hamiltonian, backend_mode=mode, grad_method=grad_method)
        loss_list = optimizer.optimize(expvalcost,)
        self.fn = expvalcost
        return loss_list

    def get_optimize_result(self):
        """
            Run the circuit that after optimization and get the result(contains states and probability)

            Return:
                Result: Include the states, counts, probability
        """
        if self.fn is None:
            raise ValueError(f'Use {self.__class__.__name__}.run() to optimize the parameterized quantum circuit first.')
        result = self.fn.run_ir(self.fn.exe)
        return result
