# Copyright 2022 SpinQ Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import numpy as np
import torch
from scipy import sparse

from spinqkit.primitive import generate_hamiltonian_matrix
from spinqkit.backend import BasicSimulatorBackend
from spinqkit.model.exceptions import InappropriateBackendError
from spinqkit.backend.pytorch_backend import TorchSimulatorBackend
from spinqkit.compiler import get_compiler


def _scipy_sparse_mat_to_torch_sparse_tensor(sparse_mx):
    """
    Convert scipy.sparse.csr_matrix to the torch.sparse.coo_tensor.

    Note:
        There are some type of torch sparse tensor cannot be applied on cuda device or used sparse grad
    """
    sparse_mx = sparse_mx.tocoo().astype(np.complex64)
    indices = torch.from_numpy(
        np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
    values = torch.from_numpy(sparse_mx.data)
    shape = torch.Size(sparse_mx.shape)
    return torch.sparse_coo_tensor(indices, values, shape)


class ExpvalCost:
    """
    With different backend to run the parameterized quantum circuit.

    Args:
        circuit (Circuit):
        params (Parameter): the params that need to be trained
        hamiltonian ([List, sparse.csr_matrix]): use generate_hamiltonian_matrix to construct the hamiltonian.
        backend_mode (str): `torch` or `spinq`. For simulator backend only support spinq or torch backend.
        grad_method (str): `backprop`, `param_shift`, `adjoint_differentiation`
    """

    def __init__(self,
                 circuit,
                 params=None,
                 hamiltonian=None,
                 compiler_mode='native',
                 backend_mode='spinq',
                 grad_method='param_shift',
                 shots=1024,
                 optimization_level=0):
        if hamiltonian is not None:
            if not isinstance(hamiltonian, (list, sparse.csr_matrix, np.ndarray)):
                raise ValueError('The hamiltonian is not supported, should be a list of pauli string with coefficient'
                                 f'or `sparse.csr_matrix` or `np.ndarray` use `generate_hamiltonian_matrix`, but got {type(hamiltonian)}')
            if backend_mode == 'torch':
                if isinstance(hamiltonian, list):
                    hamiltonian = generate_hamiltonian_matrix(hamiltonian)
                hamiltonian = _scipy_sparse_mat_to_torch_sparse_tensor(hamiltonian)

        if backend_mode == 'spinq':
            backend = BasicSimulatorBackend(shots, params)
        elif backend_mode == 'torch':
            backend = TorchSimulatorBackend(shots, params)
            if grad_method != 'backprop':
                raise ValueError(
                    'For now, `torch` backend only supported `backprop` grad_method'
                    f'But got {grad_method}'
                )
        else:
            raise InappropriateBackendError('Only `spinq` or `torch` simulator backend supports the state calculation.'
                                            f'But got {backend_mode} instead.')

        compiler = get_compiler(compiler_mode)
        exe = compiler.compile(circuit, optimization_level)

        self.exe = exe
        self.compiler = compiler
        self.qubits_num = exe.qnum
        self.optimization_level = optimization_level

        self.backend_mode = backend_mode
        self.backend = backend

        self.grad_method = grad_method
        self.hamiltonian = hamiltonian

    def update_backend_config(self, shots=None, qubits=None):
        """
        update the basic simulator backend configure shots or measure qubits
        """
        if self.backend_mode == 'spinq':
            if isinstance(qubits, int):
                qubits = [qubits]
            if not isinstance(qubits, list):
                raise ValueError('The measure qubits should be int or list'
                                 f'But got {type(qubits)}')
            self.backend.set_config(shots, qubits)

        elif self.backend_mode == 'torch':
            raise NotImplementedError('For now there are no backend configure for torch backend ')

    def run_circuit(self, circuit):
        """
        Return the states of the Circuit.
        """
        return self.run_ir(self.compiler.compile(circuit, self.optimization_level))

    def run_ir(self, exe):
        """
        Return the Result type of the IntermediateRepresentation.
        """

        if self.backend_mode == 'spinq':
            self.backend.assemble(exe)
            result = self.backend.execute(exe)
            return result

        elif self.backend_mode == 'torch':
            state = self.backend.execute(exe)
            return state

    def forward(self):
        """
        Calculating the Hamiltonian expectation.
        """
        if self.hamiltonian is None:
            raise ValueError(f'Set the hamiltonian in {self.__class__.__name__}.__init__()')
        exe = self.exe
        if self.backend_mode == 'spinq':
            value = self.backend.expval(exe, self.hamiltonian)
            return value
        elif self.backend_mode == 'torch':
            value = self.backend.expval(exe, self.hamiltonian)
            return value

    def backward(self):
        """
        Return the grads when computing over the ir

        Returns:
            grads
        """
        exe = self.exe
        if self.backend_mode == 'spinq':
            grads = self.backend.grads(exe, self.hamiltonian, self.grad_method)
            return grads
        elif self.backend_mode == 'torch':
            grads = self.backend.grads(self.grad_method)
            return grads

    def update(self, params):
        exe = self.exe
        if self.backend_mode == 'spinq':
            self.backend.update_param(exe, params)

        elif self.backend_mode == 'torch':
            self.backend.update_param(exe, params)


if __name__ == '__main__':
    pass
