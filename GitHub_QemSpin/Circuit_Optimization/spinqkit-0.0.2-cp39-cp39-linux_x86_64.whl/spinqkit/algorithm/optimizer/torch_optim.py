import time

import numpy as np
import torch
from spinqkit.backend.pytorch_backend import TorchSimulatorBackend
from spinqkit.algorithm import Optimizer

from spinqkit.model.parameter import Parameter
from torch.autograd import Function


class QuantumFunction(Function):
    """
    The class is for constructing the Pytorch Quantum model with our own quantum circuit.
    """

    @staticmethod
    def forward(ctx, params: torch.Tensor, expval_fn):
        np_params = params.numpy()
        expval_fn.update(np_params)
        expval = torch.from_numpy(expval_fn.forward())
        ctx.fn = expval_fn
        ctx.save_for_backward(params)
        return expval

    @staticmethod
    def backward(ctx, grad_output):
        expval_fn = ctx.fn
        gradients = torch.from_numpy(expval_fn.backward())
        g_params = grad_output * gradients
        return g_params, None


class QuantumModel_spinq(torch.nn.Module):
    def __init__(self,
                 expvalcost):
        super().__init__()
        init_params = expvalcost.backend.params
        if isinstance(init_params, np.ndarray):
            init_params = torch.from_numpy(init_params)
            init_params.requires_grad_()
        else:
            init_params = torch.tensor(init_params, requires_grad=True)

        self.__params = torch.nn.Parameter(init_params)
        self.__fn = expvalcost

    def forward(self):
        return QuantumFunction.apply(self.__params, self.__fn)


class QuantumModel_torch(torch.nn.Module):
    def __init__(self,
                 expvalcost):
        super().__init__()
        self.params = torch.nn.Parameter(expvalcost.backend.params)
        expvalcost.update(self.params)
        self.quantum_fn = expvalcost

    def forward(self):
        return self.quantum_fn.forward()


optim_map = {'NAdam': torch.optim.NAdam,
             'Adam': torch.optim.Adam,
             'SGD': torch.optim.SGD,
             'AdamW': torch.optim.AdamW,
             'Adagrad': torch.optim.Adagrad}


class TorchOptimizer(Optimizer):
    def __init__(self,
                 maxiter: int = 1000,
                 tolerance: float = 1e-6,
                 learning_rate: float = 0.01,
                 verbose: bool = True,
                 optim_type='NAdam',
                 *args, **kwargs):
        super().__init__()

        self.optim_type = optim_type
        self.__maxiter = maxiter
        self.__tolerance = tolerance
        self.__verbose = verbose
        self.__learning_rate = learning_rate
        self.__args = args
        self.__kwargs = kwargs

    def optimize(self, expval_fn):
        if expval_fn.backend_mode == 'torch':
            model = QuantumModel_torch(expval_fn)
        elif expval_fn.backend_mode == 'spinq':
            model = QuantumModel_spinq(expval_fn)
        else:
            raise NotImplementedError(f'The backend {expval_fn.backend_mode} are not supported')

        optimizer = optim_map[self.optim_type]
        optimizer = optimizer(model.parameters(), lr=self.__learning_rate, *self.__args, **self.__kwargs)
        loss_list = []
        for step in range(1, self.__maxiter + 1):
            optimizer.zero_grad()
            start = time.time()
            loss = self.step(model, optimizer)
            end = time.time()
            if self.__verbose:
                print('Optimize: step {}, loss: {}, time: {}s'.format(step, loss, end - start))
            if loss_list and np.abs(loss - loss_list[-1]) < self.__tolerance:
                print(f'The loss difference less than {self.__tolerance}. Optimize done')
                break
            loss_list.append(loss)
        return loss_list

    def step(self, model, optimizer):
        loss = model()
        loss.backward()
        optimizer.step()
        return loss.item()
