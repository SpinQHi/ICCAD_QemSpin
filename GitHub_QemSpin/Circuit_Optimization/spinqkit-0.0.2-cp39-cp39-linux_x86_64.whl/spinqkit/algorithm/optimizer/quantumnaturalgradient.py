import time

import numpy as np
import torch
from autograd import grad as _grad

from spinqkit.algorithm.optimizer import Optimizer
from spinqkit.model import Circuit, Instruction
from spinqkit.model.gates import basis_map
from spinqkit.primitive import PauliBuilder, calculate_pauli_expectation


def fubini_tensor(expval_fn, params):
    """
    For now, the function is only supported the 'diag' approximation.
    """

    def convert_ob(qubit, pstr):
        h_part = PauliBuilder(pstr).to_gate()
        temp_circ << (h_part, qubit)
        expval_fn.update_backend_config(qubits=qubit)
        result = expval_fn.run_circuit(temp_circ)
        value = calculate_pauli_expectation('Z', result.probabilities)
        temp_circ.instructions.pop()
        return (1 - value * value) / 4

    qubit_num = expval_fn.qubits_num
    ir = expval_fn.exe

    # Create a temporary circuit to construct the metric tensor
    temp_circ = Circuit()
    temp_circ.allocateQubits(qubit_num)
    Fubini_study_tensor = np.zeros(shape=params.shape)

    for v in ir.dag.vs:
        # Fubini tensor index
        if v['type'] == 0:
            label = v['name'].lower()
            if label == 'cnot':
                label = 'cx'
            gate = basis_map[label]
            qubit = v['qubits']
            _params = v['params']
            # The observables corresponding to the generators of the gates in the layer:
            if v['trainable']:
                func = v['trainable']
                coeff = _grad(func)(params)
                val = 0
                if label == 'rx':
                    val = convert_ob(qubit, 'X')
                elif label == 'rz':
                    val = convert_ob(qubit, 'Z')
                elif label == 'ry':
                    val = convert_ob(qubit, 'Y')
                Fubini_study_tensor += coeff * coeff * val
            temp_circ.append_instruction(Instruction(gate, qubit, [], _params))
    Fubini_study_tensor[Fubini_study_tensor == 0] = np.inf
    inv_tensor = 1 / Fubini_study_tensor
    return inv_tensor


class QuantumNaturalGradient(Optimizer):
    def __init__(self,
                 maxiter: int = 1000,
                 tolerance: float = 1e-6,
                 learning_rate: float = 0.01,
                 verbose=True, ):

        super().__init__()

        self.__maxiter = maxiter
        self.__tolerance = tolerance
        self.__learning_rate = learning_rate
        self.__verbose = verbose

    def optimize(self, expval_fn):
        params = expval_fn.backend.params
        loss_list = []
        for step in range(1, self.__maxiter + 1):
            start = time.time()
            loss = self.step(expval_fn, params)
            end = time.time()
            if self.__verbose:
                print('Optimize: step {}, loss: {}, time: {}s'.format(step, loss, end - start))
            if loss_list and np.abs(loss - loss_list[-1]) < self.__tolerance:
                print(f'The loss difference less than {self.__tolerance}. Optimize done')
                break
            loss_list.append(loss)
        return loss_list

    def step(self, expval_fn, params):
        if expval_fn.backend_mode == 'torch':
            params = params.detach().numpy()

        loss = expval_fn.forward()
        first_grads = expval_fn.backward()
        Fubini_study_tensor_inv = fubini_tensor(expval_fn, params, )
        derivative = Fubini_study_tensor_inv * first_grads
        params -= self.__learning_rate * derivative
        expval_fn.update(params)

        if isinstance(loss, torch.Tensor) and getattr(loss, 'requires_grad', None):
            # For torch backend the loss that has 'requires_grad' should be detached first
            loss = loss.detach()
        return loss


if __name__ == '__main__':
    pass
