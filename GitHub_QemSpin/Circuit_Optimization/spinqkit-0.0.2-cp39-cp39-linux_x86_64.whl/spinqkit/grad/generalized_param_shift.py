import itertools
from functools import lru_cache

import numpy as np
from autograd import grad as _grad


@lru_cache(maxsize=None)
def _get_coeffs_and_shifts(frequencies=(1.0,), tol=1e-10):
    frequencies = list(sorted(frequencies))
    R = len(frequencies)
    freq_min = frequencies[0]

    mu = np.arange(1, R + 1)
    shifts = np.pi * (2 * mu - 1) / (2 * R * freq_min)
    if len(set(np.round(np.diff(frequencies), 10))) <= 1:
        coeffs = (
                freq_min
                * (-1) ** (mu - 1)
                / (4 * R * np.sin(np.pi * (2 * mu - 1) / (4 * R)) ** 2)
        )
    else:
        sin_matrix = -4 * np.sin(np.outer(shifts, frequencies))
        coeffs = -2 * np.linalg.solve(sin_matrix.T, frequencies)

    coeffs = np.concatenate((coeffs, -coeffs))
    shifts = np.concatenate((shifts, -shifts))
    res = np.stack([coeffs, shifts]).T
    res[np.abs(res) < tol] = 0
    # remove columns where the coefficients are 0
    res = res[~(res[:, 0] == 0)]
    # sort columns according to abs(coeffs)
    res = res[np.argsort(np.abs(res[:, 0]))]
    coeffs, shifts = res[:, 0], res[:, 1]
    return coeffs, shifts


@lru_cache(maxsize=None)
def _get_eigvals(coeffs):
    s1 = {0}
    for i in range(len(coeffs)):
        tmp = set()
        for s in s1:
            tmp.add(s + coeffs[i])
            tmp.add(s - coeffs[i])
        s1 = s1.union(tmp)
    return tuple(s1)


@lru_cache(maxsize=None)
def _get_frequencies(eigvals):
    unique_eigvals = sorted(set(eigvals))
    frequencies = tuple({j - i for i, j in itertools.combinations(unique_eigvals, 2)})

    # TODO: the frequencies can be obtained in a better way
    if any(x > 1 for x in frequencies):
        frequencies = filter(lambda x: x >= 1, frequencies)
    _frequencies = []
    frequencies = sorted(frequencies)
    for j in range(len(frequencies)):
        if len(_frequencies) == 0:
            _frequencies.append(frequencies[j])
        else:
            if abs(_frequencies[-1] - frequencies[j]) < 1e-5:
                continue
            else:
                _frequencies.append(frequencies[j])
    frequencies = _frequencies
    size = 10000
    tmp = np.random.binomial(len(frequencies) - 1, 0.5, size=size)
    p = np.bincount(tmp, minlength=len(frequencies)) / size
    # sto-3g h2o [25.625, 34.875, 47.0, 52.625, 59.0, 63.0, 78.625, 87.25, 100.75, 119.625]
    frequencies = np.random.choice(frequencies, p=p, size=min(10, len(frequencies)), replace=False)
    return frequencies


def generalized_parameter_shift(circuit, params, loss_func):
    """
    The method now is for Quantum Chemistry (H2, H2O, Ch4) only.
    should be further improved
    """
    raise NotImplementedError('This method should not be used for now')
    param_inst_map = circuit.param_inst_map
    inst_param_map = circuit.inst_param_map

    grads = np.zeros_like(params, dtype=float)
    for i in range(params.size):
        value = 0
        origin_param = params[i]
        inst_idx_list = param_inst_map[(i,)]

        coefficient = [abs(inst_param_map[inst_idx][0]) for inst_idx in inst_idx_list]
        eigvals = _get_eigvals(tuple(coefficient))
        eigvals = tuple(filter(lambda x: x >= 0, eigvals))

        frequencies = _get_frequencies(tuple(eigvals))

        coeffs, shifts = _get_coeffs_and_shifts(tuple(frequencies))
        for j, shift in enumerate(shifts):
            params[i] = origin_param + shift
            value += coeffs[j] * loss_func(circuit=circuit, params=params, )
        grads[i] = value
        params[i] = origin_param

        for idx, inst_idx in enumerate(inst_idx_list):
            ins = circuit.instructions[inst_idx]
            ins.params = inst_param_map[inst_idx][0] * origin_param
    return grads
