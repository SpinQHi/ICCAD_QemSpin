import numpy as np
from autograd import grad as _grad


def parameter_shift(ir, params, hamiltonian, backend):
    grads = np.zeros_like(params, dtype=float)
    r = 0.5
    for v in ir.dag.vs:
        if v['trainable']:
            _params = v['params']
            func = v['trainable']
            coeff = _grad(func)(params)
            v['params'] = [_params[0] + np.pi / (4 * r)]
            value1 = backend.expval(ir, hamiltonian)
            v['params'] = [_params[0] - np.pi / (4 * r)]
            value2 = backend.expval(ir, hamiltonian)
            grads += coeff * (value1 - value2) * r
            v['params'] = _params
    return grads
