# Copyright 2022 SpinQ Technology Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import warnings
from functools import reduce
from typing import Tuple, List, Iterable

import numpy as np
import numbers


def is_diagonal(mat: np.ndarray) -> bool:
    """
    Check whether a matrix is a diagonal matrix or not
    """

    def nodiag_view(a):
        m = a.shape[0]
        p, q = a.strides
        return np.lib.stride_tricks.as_strided(a[:, 1:], (m - 1, m), (p + q, q))

    return (nodiag_view(mat) == 0).all()


def calculate_phase(mat1, mat2):
    """
    Calculate the phase difference between two matrix
    """
    #
    if isinstance(mat1, list):
        mat1 = np.array(mat1)
    if len(mat1.shape) != 1 and is_diagonal(mat1):
        mat1 = np.diagonal(mat1),
    if len(mat2.shape) != 1 and is_diagonal(mat2):
        mat2 = np.diagonal(mat2)

    if len(mat1.shape) == 1 and len(mat2.shape) == 1:
        global_phase_matrix = mat1 * mat2.conj()
    else:
        global_phase_matrix = np.diagonal(mat1 @ mat2.T.conj())
    global_phase = np.log(global_phase_matrix[0]) / 1j
    eq_id = np.allclose(global_phase_matrix / global_phase_matrix[0], np.ones(global_phase_matrix.shape[0]))

    if eq_id:
        return global_phase

    warnings.warn('There are no global phase between mat1 and mat2')
    return None


def _flatten(x):
    if isinstance(x, np.ndarray):
        yield from _flatten(x.flat)
    elif isinstance(x, Iterable) and not isinstance(x, (str, bytes)):
        for item in x:
            yield from _flatten(item)
    else:
        yield x


def _unflatten(flat, model):
    if isinstance(model, (numbers.Number, str)):
        return flat[0], flat[1:]

    if isinstance(model, np.ndarray):
        idx = model.size
        res = np.array(flat)[:idx].reshape(model.shape)
        return res, flat[idx:]

    if isinstance(model, Iterable):
        res = []
        for x in model:
            val, flat = _unflatten(flat, x)
            res.append(val)
        return res, flat

    raise TypeError("Unsupported type in the model: {}".format(type(model)))


def unflatten(flat, model):
    # pylint:disable=len-as-condition
    res, tail = _unflatten(np.asarray(flat), model)
    if len(tail) != 0:
        raise ValueError("Flattened iterable has more elements than the model.")
    return res
